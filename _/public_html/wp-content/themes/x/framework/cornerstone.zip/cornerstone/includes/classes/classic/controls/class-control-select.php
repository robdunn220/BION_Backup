<?php
class Cornerstone_Control_Select extends Cornerstone_Control {

	protected $default_options = array(
		'choices' => array()
  );

}